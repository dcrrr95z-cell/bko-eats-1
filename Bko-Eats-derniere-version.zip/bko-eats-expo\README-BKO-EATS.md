# Tester Bko Eats dans Expo Go

## Lancer le serveur

Depuis le dossier principal du projet, double-clique :

```text
lancer-expo-go.cmd
```

Ou lance :

```bash
cd bko-eats-expo
npx expo start --lan --port 8081
```

## Ouvrir sur telephone

1. Installe `Expo Go` sur ton telephone.
2. Mets le telephone sur le meme Wi-Fi que le PC.
3. Ouvre Expo Go.
4. Scanne le QR code affiche dans le terminal, ou entre l'URL LAN :

```text
exp://192.168.1.5:8081
```

## Ce que cette version fait

Cette version Expo Go ouvre le site HTTPS Bko Eats :

```text
https://bko-eats-1.vercel.app
```

Elle sert a tester rapidement l'application dans un cadre mobile.

Pour une vraie publication App Store / Play Store, il faudra ensuite transformer progressivement les ecrans principaux en composants natifs.
