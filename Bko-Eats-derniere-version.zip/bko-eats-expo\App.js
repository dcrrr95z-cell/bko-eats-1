import { StatusBar } from 'expo-status-bar';
import { useRef, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';

const BKO_EATS_URL = 'https://bko-eats-1.vercel.app';

export default function App() {
  const webViewRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const reload = () => {
    setLoadError('');
    webViewRef.current?.reload();
  };

  const openInBrowser = () => {
    Linking.openURL(BKO_EATS_URL);
  };

  const handleWebMessage = (event) => {
    try {
      const message = JSON.parse(event.nativeEvent.data);
      if (message.type === 'open-external-auth' && message.url) {
        Linking.openURL(message.url);
      }
    } catch {
      // Ignore messages that are not for the native wrapper.
    }
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <StatusBar style="dark" />
        <View style={styles.header}>
          <View style={styles.brandMark}>
            <Text style={styles.brandMarkText}>BE</Text>
          </View>
          <View style={styles.brandText}>
            <Text style={styles.title}>Bko Eats</Text>
            <Text style={styles.subtitle}>{isLoading ? 'Chargement...' : 'Application mobile'}</Text>
          </View>
          <Pressable style={styles.headerButton} onPress={reload}>
            <Text style={styles.headerButtonText}>Actualiser</Text>
          </Pressable>
        </View>

        <View style={styles.webFrame}>
          <WebView
            ref={webViewRef}
            source={{ uri: BKO_EATS_URL }}
            style={styles.webView}
            originWhitelist={['*']}
            javaScriptEnabled
            domStorageEnabled
            geolocationEnabled
            sharedCookiesEnabled
            thirdPartyCookiesEnabled
            setSupportMultipleWindows
            startInLoadingState
            injectedJavaScriptBeforeContentLoaded="window.BKO_EATS_EXPO_GO = true; true;"
            onMessage={handleWebMessage}
            onShouldStartLoadWithRequest={(request) => {
              if (/accounts\.google\.com|firebaseapp\.com\/__\/auth/.test(request.url)) {
                Alert.alert(
                  'Connexion Google',
                  "Google doit s'ouvrir dans le navigateur securise pour fonctionner avec Expo Go.",
                  [
                    { text: 'Annuler', style: 'cancel' },
                    { text: 'Ouvrir', onPress: () => Linking.openURL(`${BKO_EATS_URL}?login=google`) },
                  ],
                );
                return false;
              }
              return true;
            }}
            onLoadStart={() => setIsLoading(true)}
            onLoadEnd={() => setIsLoading(false)}
            onError={(event) => {
              setLoadError(event.nativeEvent.description || 'Impossible de charger Bko Eats.');
              setIsLoading(false);
            }}
            onHttpError={(event) => {
              setLoadError(`Erreur ${event.nativeEvent.statusCode}. Reessaie dans quelques secondes.`);
              setIsLoading(false);
            }}
          />

          {isLoading ? (
            <View style={styles.loadingOverlay} pointerEvents="none">
              <ActivityIndicator color="#111111" />
              <Text style={styles.loadingText}>Ouverture de Bko Eats</Text>
            </View>
          ) : null}

          {loadError ? (
            <View style={styles.errorPanel}>
              <Text style={styles.errorTitle}>Connexion impossible</Text>
              <Text style={styles.errorText} selectable>
                {loadError}
              </Text>
              <View style={styles.errorActions}>
                <Pressable style={styles.primaryAction} onPress={reload}>
                  <Text style={styles.primaryActionText}>Reessayer</Text>
                </Pressable>
                <Pressable style={styles.secondaryAction} onPress={openInBrowser}>
                  <Text style={styles.secondaryActionText}>Navigateur</Text>
                </Pressable>
              </View>
            </View>
          ) : null}
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f7f4',
  },
  header: {
    alignItems: 'center',
    backgroundColor: 'rgba(247, 247, 244, 0.96)',
    borderBottomColor: '#e7e7e2',
    borderBottomWidth: 1,
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  brandMark: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#111111',
    borderRadius: 15,
    height: 46,
    width: 46,
  },
  brandMarkText: {
    color: '#e1b653',
    fontSize: 15,
    fontWeight: '900',
  },
  brandText: {
    flex: 1,
    gap: 2,
  },
  title: {
    color: '#111111',
    fontSize: 18,
    fontWeight: '900',
  },
  subtitle: {
    color: '#73736d',
    fontSize: 12,
    fontWeight: '700',
  },
  headerButton: {
    backgroundColor: '#111111',
    borderRadius: 999,
    paddingHorizontal: 13,
    paddingVertical: 9,
  },
  headerButtonText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '800',
  },
  webFrame: {
    flex: 1,
    overflow: 'hidden',
  },
  webView: {
    flex: 1,
    backgroundColor: '#f7f7f4',
  },
  loadingOverlay: {
    alignItems: 'center',
    backgroundColor: 'rgba(247, 247, 244, 0.92)',
    bottom: 0,
    gap: 10,
    justifyContent: 'center',
    left: 0,
    position: 'absolute',
    right: 0,
    top: 0,
  },
  loadingText: {
    color: '#454540',
    fontSize: 13,
    fontWeight: '800',
  },
  errorPanel: {
    alignSelf: 'center',
    backgroundColor: '#ffffff',
    borderColor: '#e4e4df',
    borderRadius: 24,
    borderWidth: 1,
    gap: 12,
    left: 18,
    padding: 18,
    position: 'absolute',
    right: 18,
    top: 90,
  },
  errorTitle: {
    color: '#111111',
    fontSize: 18,
    fontWeight: '900',
  },
  errorText: {
    color: '#6f6f68',
    fontSize: 14,
    lineHeight: 20,
  },
  errorActions: {
    flexDirection: 'row',
    gap: 10,
  },
  primaryAction: {
    alignItems: 'center',
    backgroundColor: '#111111',
    borderRadius: 14,
    flex: 1,
    paddingVertical: 12,
  },
  primaryActionText: {
    color: '#ffffff',
    fontWeight: '900',
  },
  secondaryAction: {
    alignItems: 'center',
    backgroundColor: '#f0f0ec',
    borderRadius: 14,
    flex: 1,
    paddingVertical: 12,
  },
  secondaryActionText: {
    color: '#111111',
    fontWeight: '900',
  },
});
